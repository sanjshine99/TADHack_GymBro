import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/landing-page.dart';
// import 'package:myapp/page-1/login-signup.dart';
// import 'package:myapp/page-1/login.dart';
// import 'package:myapp/page-1/register-1.dart';
// import 'package:myapp/page-1/register-2.dart';
// import 'package:myapp/page-1/register-3.dart';
// import 'package:myapp/page-1/dashboard.dart';
// import 'package:myapp/page-1/calender.dart';
// import 'package:myapp/page-1/membership.dart';
// import 'package:myapp/page-1/near-me.dart';
// import 'package:myapp/page-1/near-me-E56.dart';
// import 'package:myapp/page-1/offers.dart';
// import 'package:myapp/page-1/chatbot.dart';
// import 'package:myapp/page-1/dropdown.dart';
// import 'package:myapp/page-1/gender-selection-page.dart';
// import 'package:myapp/page-1/user-information-page.dart';
// import 'package:myapp/page-1/fitness-goals-page.dart';
// import 'package:myapp/page-1/confirmation.dart';
// import 'package:myapp/page-1/cancel.dart';
// import 'package:myapp/page-1/workout-intensity-page.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
	return MaterialApp(
		title: 'Flutter',
		debugShowCheckedModeBanner: false,
		scrollBehavior: MyCustomScrollBehavior(),
		theme: ThemeData(
		primarySwatch: Colors.blue,
		),
		home: Scaffold(
		body: SingleChildScrollView(
			child: Scene(),
		),
		),
	);
	}
}
