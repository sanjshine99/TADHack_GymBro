import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 320;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // loginsignupeCp (21:18)
        padding: EdgeInsets.fromLTRB(66*fem, 35*fem, 67*fem, 149*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // logoY3J (85:21)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 140*fem),
              width: double.infinity,
              child: Center(
                // gym7removebgpreview2gfJ (55:3)
                child: SizedBox(
                  width: 187*fem,
                  height: 147*fem,
                  child: Image.asset(
                    'assets/page-1/images/gym7-removebg-preview-2.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Container(
              // registerD9S (21:37)
              margin: EdgeInsets.fromLTRB(14*fem, 0*fem, 14*fem, 25*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: double.infinity,
                  height: 36*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff6d72c3),
                    borderRadius: BorderRadius.circular(20*fem),
                  ),
                  child: Center(
                    child: Text(
                      'Register',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // loginaPJ (21:36)
              margin: EdgeInsets.fromLTRB(14*fem, 0*fem, 14*fem, 0*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: double.infinity,
                  height: 36*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff6d72c3),
                    borderRadius: BorderRadius.circular(20*fem),
                  ),
                  child: Center(
                    child: Text(
                      'Login',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}