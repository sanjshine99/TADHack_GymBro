import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 320;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // cancel6Rn (82:370)
        padding: EdgeInsets.fromLTRB(23*fem, 77*fem, 14*fem, 22*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // areyousuretocancelthereservati (82:383)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 44*fem),
              constraints: BoxConstraints (
                maxWidth: 272*fem,
              ),
              child: Text(
                'Are you sure to cancel\nthe reservation?',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.2125*ffem/fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            Container(
              // autogroupojgj6KJ (9H3AM39SSd1R3Svr4doJgj)
              width: double.infinity,
              height: 50*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group4ERW (82:384)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0*fem),
                    width: 135*fem,
                    height: double.infinity,
                    child: Stack(
                      children: [
                        Positioned(
                          // yesmgL (82:385)
                          left: 45*fem,
                          top: 10*fem,
                          child: Align(
                            child: SizedBox(
                              width: 45*fem,
                              height: 31*fem,
                              child: Text(
                                'Yes',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 25*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangle320diY (82:386)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 135*fem,
                              height: 50*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  border: Border.all(color: Color(0xff000000)),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group3wz8 (82:387)
                    width: 135*fem,
                    height: double.infinity,
                    child: Stack(
                      children: [
                        Positioned(
                          // nouRA (82:388)
                          left: 51*fem,
                          top: 10*fem,
                          child: Align(
                            child: SizedBox(
                              width: 34*fem,
                              height: 31*fem,
                              child: Text(
                                'No',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 25*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangle320zxQ (82:389)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 135*fem,
                              height: 50*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  border: Border.all(color: Color(0xff000000)),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}