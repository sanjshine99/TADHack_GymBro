import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 320;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // chatbotWwr (21:40)
        padding: EdgeInsets.fromLTRB(36*fem, 16*fem, 21*fem, 49.48*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff6d72c3),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // closeS4p (65:84)
              margin: EdgeInsets.fromLTRB(233*fem, 0*fem, 0*fem, 60*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 30*fem,
                  height: 30*fem,
                  child: Image.asset(
                    'assets/page-1/images/close-nLG.png',
                    width: 30*fem,
                    height: 30*fem,
                  ),
                ),
              ),
            ),
            Container(
              // hellogymbrohmS (35:61)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 19*fem),
              child: Text(
                'Hello GymBro!',
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.2125*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // removebgpreview1Qvk (35:60)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 20*fem),
              width: 248*fem,
              height: 278*fem,
              child: Image.asset(
                'assets/page-1/images/removebg-preview-1.png',
                fit: BoxFit.cover,
              ),
            ),
            Container(
              // letsgetstartedwQt (35:62)
              margin: EdgeInsets.fromLTRB(5*fem, 0*fem, 0*fem, 10*fem),
              child: Text(
                'Let’s get started',
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.2125*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // autogroupefaj3Tv (9H37WnXnqhoF1JqTZeEFaj)
              margin: EdgeInsets.fromLTRB(52*fem, 0*fem, 66*fem, 0*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // poweredbyysN (79:279)
                    margin: EdgeInsets.fromLTRB(0*fem, 1.48*fem, 9*fem, 0*fem),
                    child: Text(
                      'Powered by',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                  Container(
                    // radisyslogocolorcmyktransparen (79:278)
                    width: 50*fem,
                    height: 23.52*fem,
                    child: Image.asset(
                      'assets/page-1/images/radisyslogocolorcmyktransparent3x-1.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}