import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 320;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // register2PXe (21:24)
        padding: EdgeInsets.fromLTRB(33*fem, 32*fem, 28*fem, 47*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // closeWMN (65:89)
              margin: EdgeInsets.fromLTRB(229*fem, 0*fem, 0*fem, 44*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 30*fem,
                  height: 30*fem,
                  child: Image.asset(
                    'assets/page-1/images/close.png',
                    width: 30*fem,
                    height: 30*fem,
                  ),
                ),
              ),
            ),
            Container(
              // backgroundCV6 (85:26)
              margin: EdgeInsets.fromLTRB(23*fem, 0*fem, 29*fem, 53*fem),
              padding: EdgeInsets.fromLTRB(27*fem, 27*fem, 27*fem, 0*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/ellipse-3-Byi.png',
                  ),
                ),
              ),
              child: Align(
                // fitnesscoupleremovebgpreview1G (32:25)
                alignment: Alignment.bottomCenter,
                child: SizedBox(
                  width: 153*fem,
                  height: 175*fem,
                  child: Image.asset(
                    'assets/page-1/images/fitness-couple-removebg-preview-1-1TE.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Container(
              // textPZa (85:25)
              margin: EdgeInsets.fromLTRB(14*fem, 0*fem, 6*fem, 52*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // learntechniques81N (35:48)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 11*fem),
                    child: Text(
                      'Learn Techniques',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // ourworkoutprogramsaremadebypro (35:49)
                    constraints: BoxConstraints (
                      maxWidth: 239*fem,
                    ),
                    child: Text(
                      'Our workout programs are made by \nprofessionals ',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupumfqXJQ (9H32pFhELEodeTsvwJUMFq)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 30*fem, 0*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // arrowpoJ (79:319)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 139*fem, 1*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 45*fem,
                        height: 45*fem,
                        child: Image.asset(
                          'assets/page-1/images/arrow-Ea4.png',
                          width: 45*fem,
                          height: 45*fem,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // arrowKEG (35:34)
                    margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 45*fem,
                        height: 45*fem,
                        child: Image.asset(
                          'assets/page-1/images/arrow-36p.png',
                          width: 45*fem,
                          height: 45*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}