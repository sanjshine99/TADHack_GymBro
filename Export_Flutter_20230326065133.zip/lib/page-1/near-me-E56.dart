import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 320;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // nearmewC4 (79:335)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff6d72c3),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupqboq3F6 (9H36eUeHSYCvdwtPxzqBoq)
              padding: EdgeInsets.fromLTRB(14*fem, 22*fem, 14*fem, 32*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // dropdownakp (79:336)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 26*fem,
                        height: 26*fem,
                        child: Image.asset(
                          'assets/page-1/images/dropdown-byr.png',
                          width: 26*fem,
                          height: 26*fem,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // nearmefXN (79:343)
                    margin: EdgeInsets.fromLTRB(95*fem, 0*fem, 0*fem, 0*fem),
                    child: Text(
                      'Near Me',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 25*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupd1w3NRn (9H36Ha5TDMnaiKd1FRd1W3)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 34*fem),
              width: double.infinity,
              height: 355*fem,
              child: Stack(
                children: [
                  Positioned(
                    // reserveuAp (82:374)
                    left: 21*fem,
                    top: 278*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 135*fem,
                        height: 50*fem,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                        ),
                        child: Center(
                          child: Text(
                            'Reserve',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 25*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // cancel8JU (82:376)
                    left: 165*fem,
                    top: 278*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 135*fem,
                        height: 50*fem,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                        ),
                        child: Center(
                          child: Text(
                            'Cancel',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 25*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffff0000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // selectedtextnP2 (85:45)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(21*fem, 49*fem, 24*fem, 49*fem),
                      width: 320*fem,
                      height: 355*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffd1d5db),
                      ),
                      child: Align(
                        // selectedlocationgampahaselecte (82:350)
                        alignment: Alignment.topCenter,
                        child: SizedBox(
                          child: Container(
                            constraints: BoxConstraints (
                              maxWidth: 275*fem,
                            ),
                            child: Text(
                              'Selected location: Gampaha\nSelected Gym: ABC Gym\nPick a date:\nPick a time:',
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 20*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.2125*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupbhitjxU (9H36Uu5uomTRQUBNoRbHiT)
              margin: EdgeInsets.fromLTRB(24*fem, 0*fem, 54*fem, 0*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // back4zk (85:48)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 166*fem, 0*fem),
                    width: 26*fem,
                    height: 26*fem,
                    child: Image.asset(
                      'assets/page-1/images/back-S4x.png',
                      width: 26*fem,
                      height: 26*fem,
                    ),
                  ),
                  TextButton(
                    // chatbubble1nQx (79:341)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      width: 50*fem,
                      height: 50*fem,
                      child: Image.asset(
                        'assets/page-1/images/chat-bubble-1-mVJ.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}