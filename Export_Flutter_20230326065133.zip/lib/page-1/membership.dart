import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 320;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // membership2qE (69:200)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff6d72c3),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupk9goMsW (9H35QgNapytVC54AByK9go)
              padding: EdgeInsets.fromLTRB(14*fem, 22*fem, 14*fem, 33*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // dropdown4mv (69:202)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 26*fem,
                        height: 26*fem,
                        child: Image.asset(
                          'assets/page-1/images/dropdown-J2t.png',
                          width: 26*fem,
                          height: 26*fem,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // membershipxMW (79:326)
                    margin: EdgeInsets.fromLTRB(69*fem, 0*fem, 0*fem, 0*fem),
                    child: Text(
                      'Membership',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 25*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // packagesTp4 (85:38)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 33*fem),
              width: double.infinity,
              height: 355*fem,
              decoration: BoxDecoration (
                color: Color(0xffd1d5db),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // month3months6months12monthsBk4 (79:332)
                    left: 83*fem,
                    top: 75*fem,
                    child: Align(
                      child: SizedBox(
                        width: 153*fem,
                        height: 146*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Text(
                            '1 month\n3 months\n6 months\n12 months',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 30*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle320po2 (79:333)
                    left: 61*fem,
                    top: 126*fem,
                    child: Align(
                      child: SizedBox(
                        width: 176*fem,
                        height: 52*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xffff0000)),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupkt3hwse (9H35FMJo3az2jqBco2kT3H)
              margin: EdgeInsets.fromLTRB(24*fem, 0*fem, 54*fem, 0*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // backUsa (85:40)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 166*fem, 0*fem),
                    width: 26*fem,
                    height: 26*fem,
                    child: Image.asset(
                      'assets/page-1/images/back.png',
                      width: 26*fem,
                      height: 26*fem,
                    ),
                  ),
                  TextButton(
                    // chatbubble1cD6 (69:218)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      width: 50*fem,
                      height: 50*fem,
                      child: Image.asset(
                        'assets/page-1/images/chat-bubble-1-mh2.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}