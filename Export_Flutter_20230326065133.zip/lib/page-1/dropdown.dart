import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 249;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // dropdownanc (65:74)
        padding: EdgeInsets.fromLTRB(29*fem, 22*fem, 27*fem, 266*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // close6kx (65:75)
              margin: EdgeInsets.fromLTRB(163*fem, 0*fem, 0*fem, 69*fem),
              width: 30*fem,
              height: 30*fem,
              child: Image.asset(
                'assets/page-1/images/close-nu6.png',
                width: 30*fem,
                height: 30*fem,
              ),
            ),
            Container(
              // calenderE6U (65:81)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 81*fem, 19*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Text(
                  'Calender',
                  style: SafeGoogleFont (
                    'Inter',
                    fontSize: 25*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.2125*ffem/fem,
                    color: Color(0xff6d72c3),
                  ),
                ),
              ),
            ),
            Container(
              // membershipwWg (69:266)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 39*fem, 19*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Text(
                  'Membership',
                  style: SafeGoogleFont (
                    'Inter',
                    fontSize: 25*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.2125*ffem/fem,
                    color: Color(0xff6d72c3),
                  ),
                ),
              ),
            ),
            Container(
              // nearmeEEt (69:267)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 91*fem, 19*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Text(
                  'Near me',
                  style: SafeGoogleFont (
                    'Inter',
                    fontSize: 25*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.2125*ffem/fem,
                    color: Color(0xff6d72c3),
                  ),
                ),
              ),
            ),
            Container(
              // offerswf6 (69:268)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 115*fem, 0*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Text(
                  'Offers',
                  style: SafeGoogleFont (
                    'Inter',
                    fontSize: 25*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.2125*ffem/fem,
                    color: Color(0xff6d72c3),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}