import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 320;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: TextButton(
        // landingpageM1S (14:3)
        onPressed: () {},
        style: TextButton.styleFrom (
          padding: EdgeInsets.zero,
        ),
        child: Container(
          padding: EdgeInsets.fromLTRB(59*fem, 185*fem, 58*fem, 185*fem),
          width: double.infinity,
          height: 568*fem,
          decoration: BoxDecoration (
            color: Color(0xff6d72c3),
          ),
          child: Container(
            // logoJsi (85:20)
            width: double.infinity,
            height: double.infinity,
            child: Center(
              // gym7removebgpreview1TVi (55:2)
              child: SizedBox(
                width: 203*fem,
                height: 198*fem,
                child: Image.asset(
                  'assets/page-1/images/gym7-removebg-preview-1.png',
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
        ),
      ),
          );
  }
}