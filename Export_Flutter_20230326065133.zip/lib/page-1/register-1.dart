import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 320;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // register12ZN (21:21)
        padding: EdgeInsets.fromLTRB(56*fem, 32*fem, 28*fem, 47*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              // closeWzL (40:11)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 44*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 30*fem,
                  height: 30*fem,
                  child: Image.asset(
                    'assets/page-1/images/close-jWp.png',
                    width: 30*fem,
                    height: 30*fem,
                  ),
                ),
              ),
            ),
            Container(
              // backgroundbkt (85:23)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 29*fem, 53*fem),
              padding: EdgeInsets.fromLTRB(27*fem, 27*fem, 27*fem, 0*fem),
              decoration: BoxDecoration (
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/ellipse-1.png',
                  ),
                ),
              ),
              child: Align(
                // fitnesscoupleremovebgpreview16 (32:23)
                alignment: Alignment.bottomCenter,
                child: SizedBox(
                  width: 153*fem,
                  height: 175*fem,
                  child: Image.asset(
                    'assets/page-1/images/fitness-couple-removebg-preview-1-3qi.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Container(
              // textdSg (85:24)
              margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 25*fem, 53*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // workoutanywhere8eL (35:44)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 11*fem),
                    child: Text(
                      'Workout  Anywhere',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // youcanchooseanygymanywherewith (35:45)
                    constraints: BoxConstraints (
                      maxWidth: 202*fem,
                    ),
                    child: Text(
                      'You can choose any gym,\nanywhere within your package',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // arrowvaC (32:33)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 29*fem, 0*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 45*fem,
                  height: 45*fem,
                  child: Image.asset(
                    'assets/page-1/images/arrow.png',
                    width: 45*fem,
                    height: 45*fem,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}